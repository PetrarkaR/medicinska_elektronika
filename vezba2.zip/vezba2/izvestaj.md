donja granicna frekvencija je 48.5mHz
dok je gornja 20.9kHz

pojacanje na srednjim frekvencijama Ad=54.6dB

formula za izracunavanje Ad=(1+(2R_1/Rg))*(R3/R2)

pretvori datu vrednost u decibele

kondenzatori c1 i c2 uticu na fd

formula za je fc=1/2 pi R2 C
poklapaju se izracunavanje i ovo

cmmr

max je 3.6V

max As=Voutput/Vinput = 1,2 

ad=53.009dB



PROJEKAT B

Ad=55.8db

isto je ista formula isti kur


64.5mHz 
21.0kHz


cmmr B

Vamp = 2.53V

As = 0.843

Ad = 56.080db


AMPC
Ad=53.5db
CMMR = 52.3dB
V=3.41V
As=1.13
fd=8mhz
fg=31.3Khz



AmpD
Ad=53.5dB
CMMR = 53.915dB
V=2.86V
As=0.953
fd=80mHz
fg=64khz
