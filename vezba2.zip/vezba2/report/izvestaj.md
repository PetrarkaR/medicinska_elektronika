donja granicna frekvencija je 48.5mHz
dok je gornja 20.9kHz

pojacanje na srednjim frekvencijama Ad=54.6dB

formula za izracunavanje Ad=(1+(2R_1/Rg))*(R3/R2)

pretvori datu vrednost u decibele

kondenzatori c1 i c2 uticu na fd

formula za je fc=1/RC


cmmr

max je 3.6V

max As=Voutput/Vinput = 1.3V

ad=8.66db



PROJEKAT B

Ad=54.6dB

isto je ista formula isti kur


78mHz 
15.1kHz
